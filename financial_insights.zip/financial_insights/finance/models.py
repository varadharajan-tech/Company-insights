from django.db import models

class analysis(models.Model):
    company_name = models.CharField(max_length=200)
    break_even_point= models.CharField(max_length=200)
    revenue= models.CharField(max_length=200)
    def __str__(self):
        return self.company_name

class query(models.Model):
    query_text = models.CharField(max_length=200)
    def __str__(self):
        return self.query_text