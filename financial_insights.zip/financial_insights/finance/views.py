from django.db.models import F
from django.http import HttpResponse, HttpResponseRedirect
from django.http import Http404
from django.shortcuts import render
from django.urls import reverse
from .models import query
import sqlite3
from django.conf import settings
from pymilvus import FieldSchema, CollectionSchema, DataType, Collection, connections, MilvusClient
from sentence_transformers import SentenceTransformer


db_path = settings.DATABASES["default"]["NAME"]
conn = sqlite3.connect(db_path)
cursor = conn.cursor()
cursor.execute("SELECT * FROM finance_analysis")
rows = cursor.fetchall()
model = SentenceTransformer('all-mpnet-base-v2')
search_params = {
"metric_type": "COSINE",
"params": {}
}


def index(request):
 return render(request, "finance/index.html", {"rows": rows})

def search(request):
 try:
  user_query = request.POST["search"]
 except KeyError:
  # Redisplay the question voting form.
  return render(
   request,
   "finance/index.html",
   {
    "rows": rows,
    'error_message': "Search Field can't be blank"
   }
  )
 else:
  if user_query == '':
   # Redisplay the question voting form.
   return render(
    request,
    "finance/index.html",
    {
     "rows": rows,
     'error_message': "Search Field can't be blank"
    }
   )
  else:
   q = query.objects.get(id=2)
   q.query_text = user_query
   q.save()
   return HttpResponseRedirect(reverse("finance:results"))

def results(request):
 try:
  client = MilvusClient(
   uri="https://in03-aabe74271d9e4f2.serverless.gcp-us-west1.cloud.zilliz.com",
   token="a914fa9d5df638bd41d7a120cb22392053dca0b52682c31ecf37f15c143cd209a8073638469827b53882e456a8d57110cbf54d81"
   )
 except Exception as e:
  print(f"Failed to connect to Milvus: {e}")
 q = query.objects.get(id=2)
 embeddings = model.encode([q.query_text]).tolist()
 try:
  response = client.search(
  collection_name="finance",
  data=embeddings,
  limit=3,
  output_fields=["source"],
  search_params=search_params
  )
 except Exception as e:
  print(f"Failed to retrieve the source: {e}")
 response_source = []
 for x in response[0]:
  content_list = []
  splitted_source = x['entity']['source'].split(' ::: ')
  readable_source = splitted_source[0] + ': ' + splitted_source[1].replace('\n', '. ')
  response_source.append(readable_source)
 return render(
  request,
  "finance/results.html",
  {
   "response_source": response_source
  }
 )

conn.close()
